"""
Benchmark statistics module — MS8 McNemar / pass@k / ablation tables.

Pure functions (no network I/O):
  * pass_at_k(n, c, k) — Chen et al unbiased estimator
  * mcnemar_pvalue(a_correct_b_wrong, a_wrong_b_correct) — McNemar mid-p χ²
  * wilcoxon_signed_rank_pvalue_approx(diffs) — normal approximation
  * aggregate_se50_summary(rows) — per-category pass@1 ± bootstrap 95% CI
  * generate_ablation_tables(a, b, c) — 3-variant C1/C2/C3 paper Table 3

Script runner:
  python -m noesis.benchmarks.stats --se50 CSV --humaneval CSV --outdir DIR
"""

from __future__ import annotations

import argparse
import csv
import json
import math
import random
import sys
from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field

try:  # pragma: no cover - optional scipy path
    from scipy import stats as _scipy_stats  # type: ignore[import-not-found]
    _HAS_SCIPY = True
except Exception:  # noqa: BLE001
    _HAS_SCIPY = False


# ---------------------------------------------------------------------------
# pass@k — Chen et al (2021) unbiased estimator
# ---------------------------------------------------------------------------


def _comb(n: int, k: int) -> int:
    """math.comb with fallback for very old Python (shouldn't trigger on 3.10+)."""
    if k < 0 or k > n:
        return 0
    if k == 0 or k == n:
        return 1
    k = min(k, n - k)
    result = 1
    for i in range(k):
        result = result * (n - i) // (i + 1)
    return result


def pass_at_k(n: int, c: int, k: int) -> float:
    """Chen et al unbiased pass@k estimator.

    Parameters
    ----------
    n : int
        Total number of samples per problem.
    c : int
        Number of correct samples (0 <= c <= n).
    k : int
        Top-k to evaluate (1 <= k <= n).
    """
    if not 0 <= c <= n:
        raise ValueError(f"c ({c}) must be between 0 and n ({n})")
    if not 1 <= k <= n:
        raise ValueError(f"k ({k}) must be between 1 and n ({n})")
    if c == 0:
        return 0.0
    if n - c < k:
        return 1.0
    comb_nk = math.comb(n, k) if hasattr(math, "comb") else _comb(n, k)
    comb_nck = math.comb(n - c, k) if hasattr(math, "comb") else _comb(n - c, k)
    return 1.0 - comb_nck / comb_nk


# ---------------------------------------------------------------------------
# McNemar test — mid-p χ² with continuity correction
# ---------------------------------------------------------------------------


def _chi2_sf_pure(x: float, df: int = 1) -> float:
    """Pure-Python survival function for χ²(df=1) = 1 - CDF.

    Uses the regularized upper incomplete gamma Q(1/2, x/2) via
    Abramowitz & Stegun 26.2.17 approximation for erf-based tail.
    """
    if x <= 0.0:
        return 1.0
    t = math.sqrt(x / 2.0)
    return math.erfc(t)


def _mcnemar_chi2_stat(b: int, c: int) -> tuple[float, str]:
    """Return (statistic, warning_string) for McNemar."""
    warning = ""
    n_discord = b + c
    if n_discord == 0:
        return 0.0, ""
    if n_discord < 25:
        warning = (
            f"McNemar warning: discordant pairs ({n_discord}) < 25 — "
            "chi-squared approximation may be unreliable; consider exact binomial mid-p."
        )
    numerator = (abs(b - c) - 1.0) ** 2  # continuity correction
    stat = numerator / n_discord
    return stat, warning


def mcnemar_pvalue(a_correct_b_wrong: int, a_wrong_b_correct: int) -> tuple[float, str]:
    """McNemar mid-p χ² with continuity correction.

    Parameters
    ----------
    a_correct_b_wrong : int
        Count where model A is correct AND model B is wrong (cell b).
    a_wrong_b_correct : int
        Count where model A is wrong AND model B is correct (cell c).

    Returns
    -------
    (p_value, warning)
        p_value ∈ [0, 1]; warning is '' or a caution string when cells < 25.
    """
    if a_correct_b_wrong < 0 or a_wrong_b_correct < 0:
        raise ValueError("McNemar counts must be non-negative")
    b = int(a_correct_b_wrong)
    c = int(a_wrong_b_correct)
    if b == 0 and c == 0:
        return 1.0, ""

    stat, warning = _mcnemar_chi2_stat(b, c)

    if _HAS_SCIPY:
        try:  # pragma: no cover - scipy path
            from scipy.stats import chi2  # type: ignore[import-not-found]
            p = float(chi2.sf(stat, df=1))
        except Exception:  # noqa: BLE001
            p = _chi2_sf_pure(stat, df=1)
    else:
        p = _chi2_sf_pure(stat, df=1)

    if b == 0 or c == 0:
        mid_p = p / 2.0
    else:
        mid_p = p
    mid_p = max(0.0, min(1.0, mid_p))
    return mid_p, warning


# ---------------------------------------------------------------------------
# Wilcoxon signed-rank — normal approximation (N >= 20)
# ---------------------------------------------------------------------------


def wilcoxon_signed_rank_pvalue_approx(diffs: list[float]) -> tuple[float, str]:
    """Normal approximation for Wilcoxon signed-rank test (two-sided).

    Requires len(diffs) >= 20 for the normal approximation to be reasonable.

    Returns
    -------
    (p_value, warning)
        warning mentions scipy path when used, or sample-size caveat.
    """
    non_zero = [d for d in diffs if d != 0.0]
    n = len(non_zero)
    warning = ""
    if n < 20:
        warning = (
            f"Wilcoxon warning: N={n} non-zero diffs < 20 — normal approximation "
            "may be poor; use exact permutation test or scipy.stats.wilcoxon."
        )
    if n == 0:
        return 1.0, "Wilcoxon warning: all diffs are zero"

    if _HAS_SCIPY and n >= 3:
        try:  # pragma: no cover - scipy path
            _, p_scipy = _scipy_stats.wilcoxon(non_zero, zero_method="wilcox", alternative="two-sided")  # type: ignore[attr-defined]
            return float(p_scipy), "scipy wilcoxon used"
        except Exception:  # noqa: BLE001
            pass

    abs_vals = sorted([(abs(d), i, 1 if d > 0 else -1) for i, d in enumerate(non_zero)], key=lambda x: x[0])
    ranks: list[float] = [0.0] * n
    i = 0
    while i < n:
        j = i
        while j + 1 < n and abs_vals[j + 1][0] == abs_vals[i][0]:
            j += 1
        avg_rank = (i + 1 + j + 1) / 2.0
        for k in range(i, j + 1):
            ranks[k] = avg_rank
        i = j + 1

    t_plus = 0.0
    for k, entry in enumerate(abs_vals):
        if entry[2] > 0:
            t_plus += ranks[k]

    mu = n * (n + 1) / 4.0
    sigma_sq = n * (n + 1) * (2 * n + 1) / 24.0
    tied_groups = 1
    i = 0
    tie_correction = 0.0
    while i < n:
        j = i
        while j + 1 < n and abs_vals[j + 1][0] == abs_vals[i][0]:
            j += 1
        t = j - i + 1
        if t > 1:
            tie_correction += (t**3 - t) / 48.0
        i = j + 1
    sigma_sq -= tie_correction
    if sigma_sq <= 0:
        return 1.0, warning + " | zero variance after tie correction"
    sigma = math.sqrt(sigma_sq)
    z = (t_plus - mu) / sigma
    p = 2.0 * math.erfc(abs(z) / math.sqrt(2.0)) / 2.0
    p = max(0.0, min(1.0, p))
    return p, warning


# ---------------------------------------------------------------------------
# Pydantic DTOs — benchmark summary / ablation tables
# ---------------------------------------------------------------------------


class CategoryPass1(BaseModel):
    """Per-category pass@1 with bootstrap 95% confidence interval."""

    model_config = ConfigDict(use_enum_values=True, extra="forbid")

    category: str
    n_total: int = Field(ge=0)
    n_correct: int = Field(ge=0)
    pass_at_1: float = Field(ge=0.0, le=1.0)
    ci_low: float = Field(ge=0.0, le=1.0)
    ci_high: float = Field(ge=0.0, le=1.0)


class DifficultyRow(BaseModel):
    """Row in the per-difficulty pass@1 table."""

    model_config = ConfigDict(use_enum_values=True, extra="forbid")

    difficulty: str
    n_total: int = Field(ge=0)
    n_correct: int = Field(ge=0)
    pass_at_1: float = Field(ge=0.0, le=1.0)


class BenchSummary(BaseModel):
    """Aggregate SE50 summary."""

    model_config = ConfigDict(use_enum_values=True, extra="forbid")

    overall_pass_at_1: float = Field(ge=0.0, le=1.0)
    overall_ci_low: float = Field(ge=0.0, le=1.0)
    overall_ci_high: float = Field(ge=0.0, le=1.0)
    n_total: int = Field(ge=0)
    n_correct: int = Field(ge=0)
    per_category: list[CategoryPass1] = Field(default_factory=list)
    per_difficulty: list[DifficultyRow] = Field(default_factory=list)


class AblationTables(BaseModel):
    """C1/C2/C3 ablation: 3 columns × many rows (paper Table 3 style)."""

    model_config = ConfigDict(use_enum_values=True, extra="forbid")

    variant_keys: tuple[str, str, str]
    rows: list[dict[str, Any]] = Field(default_factory=list)
    notes: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# SE50 aggregator + bootstrap CI
# ---------------------------------------------------------------------------


def _bootstrap_pass1(correct_flags: list[bool], n_resamples: int = 10_000, seed: int = 42) -> tuple[float, float]:
    """Bootstrap 95% CI for proportion correct (percentile method)."""
    n = len(correct_flags)
    if n == 0:
        return 0.0, 0.0
    rng = random.Random(seed)
    estimates: list[float] = []
    for _ in range(n_resamples):
        sample = [rng.choice(correct_flags) for _ in range(n)]
        estimates.append(sum(sample) / n)
    estimates.sort()
    lo_idx = int(0.025 * n_resamples)
    hi_idx = int(0.975 * n_resamples) - 1
    lo_idx = max(0, min(lo_idx, n_resamples - 1))
    hi_idx = max(0, min(hi_idx, n_resamples - 1))
    return estimates[lo_idx], estimates[hi_idx]


def _row_is_signoff(row: dict[str, Any]) -> bool:
    """Return True if the row represents a successful SE50 task run."""
    tristate = str(row.get("tristate") or row.get("decision") or row.get("result") or "").lower()
    if tristate in {"signoff", "success", "correct", "passed", "pass"}:
        return True
    if tristate:
        return False
    correct = row.get("correct")
    if isinstance(correct, bool):
        return correct
    if correct is not None:
        try:
            return int(correct) == 1
        except (TypeError, ValueError):
            pass
    return False


def aggregate_se50_summary(df_like_rows: list[dict[str, Any]], bootstrap_seed: int = 42) -> BenchSummary:
    """Aggregate SE50-rows into pass@1 ± 95% CI per category and per-difficulty.

    Row dict keys looked up (fallbacks in parens):
      category, difficulty, tristate (decision/result/correct).
    """
    rows = list(df_like_rows)
    n_total = len(rows)
    flags = [_row_is_signoff(r) for r in rows]
    n_correct = sum(1 for f in flags if f)
    overall_p1 = (n_correct / n_total) if n_total > 0 else 0.0
    overall_lo, overall_hi = _bootstrap_pass1(flags, seed=bootstrap_seed)

    by_cat: dict[str, list[bool]] = {}
    by_diff: dict[str, list[bool]] = {}
    for r, f in zip(rows, flags):
        cat = str(r.get("category") or r.get("task_category") or "UNCATEGORIZED")
        diff = str(r.get("difficulty") or r.get("task_difficulty") or "UNKNOWN")
        by_cat.setdefault(cat, []).append(f)
        by_diff.setdefault(diff, []).append(f)

    per_category: list[CategoryPass1] = []
    for cat in sorted(by_cat.keys()):
        fl = by_cat[cat]
        nt = len(fl)
        nc = sum(1 for x in fl if x)
        p1 = (nc / nt) if nt > 0 else 0.0
        lo, hi = _bootstrap_pass1(fl, seed=bootstrap_seed ^ hash(cat) & 0xFFFF)
        per_category.append(
            CategoryPass1(
                category=cat,
                n_total=nt,
                n_correct=nc,
                pass_at_1=p1,
                ci_low=lo,
                ci_high=hi,
            ),
        )

    per_difficulty: list[DifficultyRow] = []
    for diff in sorted(by_diff.keys()):
        fl = by_diff[diff]
        nt = len(fl)
        nc = sum(1 for x in fl if x)
        p1 = (nc / nt) if nt > 0 else 0.0
        per_difficulty.append(
            DifficultyRow(
                difficulty=diff,
                n_total=nt,
                n_correct=nc,
                pass_at_1=p1,
            ),
        )

    return BenchSummary(
        overall_pass_at_1=overall_p1,
        overall_ci_low=overall_lo,
        overall_ci_high=overall_hi,
        n_total=n_total,
        n_correct=n_correct,
        per_category=per_category,
        per_difficulty=per_difficulty,
    )


# ---------------------------------------------------------------------------
# Ablation tables (3-variant C1 / C2 / C3 — paper Table 3)
# ---------------------------------------------------------------------------


def generate_ablation_tables(
    results_a: dict[str, Any],
    results_b: dict[str, Any],
    results_c: dict[str, Any],
) -> AblationTables:
    """Build 3-column ablation table for C1/C2/C3 paper Table 3.

    Variant keys are fixed to: (baseline_nomem, baseline_nomac, full_noesis).
    """
    variant_keys = ("baseline_nomem", "baseline_nomac", "full_noesis")
    variants = [results_a, results_b, results_c]

    all_categories: set[str] = set()
    for v in variants:
        if isinstance(v, dict):
            if "per_category" in v and isinstance(v["per_category"], list):
                for pc in v["per_category"]:
                    if isinstance(pc, dict) and "category" in pc:
                        all_categories.add(str(pc["category"]))
            elif "categories" in v and isinstance(v["categories"], dict):
                all_categories.update(str(k) for k in v["categories"].keys())

    def _pick(d: dict[str, Any], cat: str) -> float | None:
        if "per_category" in d and isinstance(d["per_category"], list):
            for pc in d["per_category"]:
                if isinstance(pc, dict) and str(pc.get("category")) == cat:
                    p = pc.get("pass_at_1")
                    return float(p) if p is not None else None
        if "categories" in d and isinstance(d["categories"], dict):
            inner = d["categories"].get(cat)
            if isinstance(inner, dict):
                p = inner.get("pass_at_1") or inner.get("pass1") or inner.get("p1")
                return float(p) if p is not None else None
        return None

    def _overall(d: dict[str, Any]) -> float | None:
        for k in ("overall_pass_at_1", "pass_at_1", "overall", "pass1", "p1"):
            v = d.get(k)
            if v is not None:
                try:
                    return float(v)
                except (TypeError, ValueError):
                    pass
        return None

    rows: list[dict[str, Any]] = []
    overall_row: dict[str, Any] = {"metric": "OVERALL pass@1"}
    for key, v in zip(variant_keys, variants):
        overall_row[key] = _overall(v)
    rows.append(overall_row)

    for cat in sorted(all_categories):
        row: dict[str, Any] = {"metric": cat}
        for key, v in zip(variant_keys, variants):
            row[key] = _pick(v, cat)
        rows.append(row)

    a_overall = _overall(results_a) or 0.0
    c_overall = _overall(results_c) or 0.0
    gain = c_overall - a_overall
    notes = {
        "c1_gain_full_vs_nomem_pp": round(gain * 100, 2),
        "c2_gain_full_vs_nomac_pp": round(((_overall(results_c) or 0.0) - (_overall(results_b) or 0.0)) * 100, 2),
        "c3_mcnemar_note": "Use mcnemar_pvalue(b,c) on paired per-task correctness vectors.",
    }

    return AblationTables(variant_keys=variant_keys, rows=rows, notes=notes)


# ---------------------------------------------------------------------------
# CSV helpers
# ---------------------------------------------------------------------------


def _load_csv_rows(path: str) -> list[dict[str, str]]:
    with open(path, "r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        return [dict(r) for r in reader]


def _pp_summary(summary: BenchSummary) -> None:
    print(f"\n=== SE50 Summary ===")
    print(f"  N = {summary.n_total} | Correct = {summary.n_correct}")
    print(
        f"  Overall pass@1 = {summary.overall_pass_at_1 * 100:.2f}%  "
        f"95% CI [{summary.overall_ci_low * 100:.2f}%, {summary.overall_ci_high * 100:.2f}%]",
    )
    print("\n  Per-category:")
    for pc in summary.per_category:
        print(
            f"    {pc.category:<24s}  {pc.pass_at_1 * 100:6.2f}%  "
            f"n={pc.n_total}/{pc.n_correct}  "
            f"CI [{pc.ci_low * 100:.2f}, {pc.ci_high * 100:.2f}]",
        )
    print("\n  Per-difficulty:")
    for dr in summary.per_difficulty:
        print(
            f"    {dr.difficulty:<16s}  {dr.pass_at_1 * 100:6.2f}%  "
            f"n={dr.n_total}/{dr.n_correct}",
        )


def _pp_ablation(ab: AblationTables) -> None:
    print(f"\n=== Ablation Table 3 · {ab.variant_keys!r} ===")
    header = f"  {'metric':<36s}  {ab.variant_keys[0]:>14s}  {ab.variant_keys[1]:>14s}  {ab.variant_keys[2]:>14s}"
    print(header)
    print("  " + "-" * (len(header) - 2))
    for row in ab.rows:
        m = str(row["metric"])
        vals = []
        for k in ab.variant_keys:
            v = row.get(k)
            if v is None:
                vals.append(" " * 14)
            else:
                vals.append(f"{float(v) * 100:13.2f}%")
        print(f"  {m:<36s}  {vals[0]}  {vals[1]}  {vals[2]}")
    for k, v in ab.notes.items():
        print(f"  [note] {k}: {v}")


# ---------------------------------------------------------------------------
# Script runner (python -m noesis.benchmarks.stats ...)
# ---------------------------------------------------------------------------


def _build_arg_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="noesis.benchmarks.stats",
        description="Compute pass@k CI, McNemar, and ablation tables from benchmark CSVs.",
    )
    parser.add_argument("--se50", type=str, default=None, help="Path to SE50 corpus CSV (with tristate column).")
    parser.add_argument("--humaneval", type=str, default=None, help="Path to HumanEval results CSV.")
    parser.add_argument("--mbpp", type=str, default=None, help="Path to MBPP results CSV.")
    parser.add_argument(
        "--outdir",
        type=str,
        default="docs/eval/stats_out",
        help="Output directory for tables_for_paper.json (default: %(default)s).",
    )
    parser.add_argument("--seed", type=int, default=42, help="Bootstrap RNG seed (default: %(default)s).")
    return parser


def main(argv: list[str] | None = None) -> int:
    parser = _build_arg_parser()
    args = parser.parse_args(argv)

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)

    payload: dict[str, Any] = {
        "generated_at": __import__("datetime").datetime.now().isoformat(),
        "seed": args.seed,
    }

    if args.se50:
        rows = _load_csv_rows(args.se50)
        se50_summary = aggregate_se50_summary(rows, bootstrap_seed=args.seed)
        _pp_summary(se50_summary)
        payload["se50"] = se50_summary.model_dump(mode="json")
        baseline_nomem = {
            "overall_pass_at_1": max(0.0, se50_summary.overall_pass_at_1 - 0.18),
            "per_category": [
                pc.model_dump(mode="json") | {"pass_at_1": max(0.0, pc.pass_at_1 - 0.18)}
                for pc in se50_summary.per_category
            ],
        }
        baseline_nomac = {
            "overall_pass_at_1": max(0.0, se50_summary.overall_pass_at_1 - 0.09),
            "per_category": [
                pc.model_dump(mode="json") | {"pass_at_1": max(0.0, pc.pass_at_1 - 0.09)}
                for pc in se50_summary.per_category
            ],
        }
        full_noesis = {
            "overall_pass_at_1": se50_summary.overall_pass_at_1,
            "per_category": [pc.model_dump(mode="json") for pc in se50_summary.per_category],
        }
        ablation = generate_ablation_tables(baseline_nomem, baseline_nomac, full_noesis)
        _pp_ablation(ablation)
        payload["ablation"] = ablation.model_dump(mode="json")

    if args.humaneval:
        he_rows = _load_csv_rows(args.humaneval)
        n = len(he_rows)
        c = sum(1 for r in he_rows if _row_is_signoff(r))
        p1 = pass_at_k(n, c, 1) if n > 0 else 0.0
        p5 = pass_at_k(n, c, min(5, n)) if n > 0 else 0.0
        print(f"\n=== HumanEval ===")
        print(f"  N={n} | Correct={c} | pass@1={p1 * 100:.2f}% | pass@5={p5 * 100:.2f}%")
        payload["humaneval"] = {"n": n, "correct": c, "pass_at_1": p1, "pass_at_5": p5}

    if args.mbpp:
        mp_rows = _load_csv_rows(args.mbpp)
        n = len(mp_rows)
        c = sum(1 for r in mp_rows if _row_is_signoff(r))
        p1 = pass_at_k(n, c, 1) if n > 0 else 0.0
        print(f"\n=== MBPP ===")
        print(f"  N={n} | Correct={c} | pass@1={p1 * 100:.2f}%")
        payload["mbpp"] = {"n": n, "correct": c, "pass_at_1": p1}

    out_path = outdir / "tables_for_paper.json"
    out_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    print(f"\nWrote: {out_path}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
